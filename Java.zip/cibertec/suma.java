package cibertec;

import java.util.Scanner;

public class VentaYogurt {

public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	//Definicion de variables 
	
	int base, altura,area; 
	System.out.println("Ingrese base:");
	//Leer
	base=scanner.nextInt();
	
	System.out.println("Ingrese altura:");
	altura=scanner.nextInt();
	
	//proceso
	area=base*altura;
			
	//Escribir
	System.out.println("El Area del rectangulo es:" + area);
}
}