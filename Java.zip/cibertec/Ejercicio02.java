package cibertec;

import java.util.Scanner;

public class Ejercicio02 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
       //Definimos los identificadores 
	   //Doble representa a los numeros reales 
		
 double electronica, economia, sistemas, civil, minas, dinero;
 //sysout+control con espacio;
        System.out.println("Hola! Estoy listo para calcular tus egresos");
		System.out.println("Dime ¿Cuanto dinero se va a repartir?");
		dinero=scanner.nextDouble();
		
		//Proceso
		
		civil=0.25*dinero;
		sistemas=0.7*civil;
		economia=0.45*(civil+sistemas);
		electronica=0.75*economia;
		minas=dinero-(civil+sistemas+economia+electronica);
		
		System.out.println("A Ing. Civil le corresponde: " + civil);
		System.out.println("A Ing. Sitemas le corresponde:" + sistemas);
		System.out.println("A Ing. Economia le corresponde: " + economia);
		System.out.println("A Ing. Electronica le corresponde: " + electronica);
		System.out.println("A Ing. Minas le corresponde: " + minas);
		
		System.out.println("GRACIAS POR USAR NUESTRA PLATAFORMA");
	}

}
