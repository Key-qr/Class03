package cibertec;

public class Universidad {
}
public static void main(String[] args) {

double electronica, economia, sistemas, civil, minas, dinero;
